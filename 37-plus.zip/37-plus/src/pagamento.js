import React from 'react';

const Payment = ({ carrello }) => {
  return (
    <div>
      <h2>Riepilogo dell'ordine</h2>
      <ul>
        {carrello && carrello.map(corso => (
          <li key={corso.id}>{corso.title}</li>
        ))}
      </ul>
      <button>Conferma Pagamento</button>
    </div>
  );
};

export default Payment;

