import React from 'react';

const Navigation = () => {
  return (
    <nav>
      <div className="logo">
        <img src="" alt="Logo" />
      </div>
      <ul>
        <li><a href="/">Home</a></li>
        <li><a href="/about">Corsi</a></li>
        <li><a href="/contact">Contatti</a></li>
      </ul>
    </nav>
  );
};

export default Navigation;
