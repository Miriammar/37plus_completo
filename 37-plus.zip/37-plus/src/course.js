import React from "react";

const courses = [
    {
      id: 1,
      title: 'Corso di Sicurezza sul Lavoro Art.37',
      imageUrl: 'Art.37.jpg',
      description: 'Un corso introduttivo sulla sicurezza sul lavoro.',
      duration: '2 settimane',
    
    },
    {
      id: 2,
      title: 'Corso di Ludopatia',
      description: 'Approfondimento sulla gestione dei rischi nelle industrie.',
      duration: '3 settimane',
      imageUrl: 'RLS.jpg',
    },
    {
      id: 3,
      title: 'Primo Soccorso in Ambiente Lavorativo',
      description: 'Impara le tecniche di primo soccorso applicate al lavoro.',
      duration: '1 settimana',
      imageUrl: 'RSPP.jpg',
    },
    {
        id: 4,
        title: 'Rappresentante dei lavoratori',
        description: 'Impara le tecniche di primo soccorso applicate al lavoro.',
        duration: '1 settimana',
        imageUrl: 'RSPP2.jpg',
      },
      {
        id: 5,
        title: 'RSPP',
        description: 'Impara le tecniche di primo soccorso applicate al lavoro.',
        duration: '1 settimana',
        imageUrl: 'RSPP.png'
        },
      ]

  export default courses;
  
  