import { useParams } from 'react-router-dom';

const CourseDetails = ({ courses }) => {
  const { courseId } = useParams();

  const course = courses.find((c) => c.id.toString() === courseId);

  if (!course) {
    return <div>Corso non trovato</div>;
  }

  return (
    <div>
      <h2>{course.title}</h2>
      <img src={course.imageUrl} alt={course.title} style={{ width: '100%', height: 'auto', objectFit: 'cover' }} />
      <p>Descrizione: {course.description}</p>
      <p>Durata: {course.duration}</p>
    </div>
  );
};

export default CourseDetails;
