import React from 'react';




const Footer = () => {
    return (
      <footer>
        <p> 37Plus - La tua sicurezza a portata di click </p>
        </footer>
    );
  };
    export default Footer;
    
