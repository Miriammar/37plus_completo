import React, {useState} from 'react';
import { BrowserRouter as Router, Link, Routes, Route } from 'react-router-dom';
import SearchBar from './searchbar';
import CourseList from './CourseList';
import CourseDetails from './CourseDetails';
import Footer from './footer'; // Assicurati di importare il componente Footer
import { ReactComponent as CartIcon } from './assets/cart.svg';
import LoginPage from './loginPage';
import logoImage from './Logo.png';
import coursesData from './course';
import PaymentPage from './pagamento';
import './App.css';

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginPage, setShowLoginPage] = useState(false);
  const [dati, setDati] = useState('');
  const filteredCourses = coursesData.filter((course) => course.title.toLowerCase().includes(searchTerm.toLowerCase()));
  const [isPaymentPhase, setIsPaymentPhase] = useState(false);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleAddToCart = (courseId) => {
    const courseToAdd = coursesData.find((c) => c.id === courseId);
    setCart([...cart, courseToAdd]);
  };

  const handleRemoveFromCart = (courseId) => {
    const updatedCart = cart.filter((item) => item.id !== courseId);
    setCart(updatedCart);
  };

  const handleLogin = () => {
    setIsLoggedIn(true);
    setShowLoginPage(false);
  };

  const procediAlPagamento = () => {
    if (cart.length > 0 && !isLoggedIn) {
      const loginPageUrl = './loginPage.html';
      window.open(loginPageUrl, '', '');
    } else {
      setIsPaymentPhase(true);
    }
  };

  const handleDettagliClick = (courseId) => {
    // Logica per la gestione dei dettagli, ad esempio il reindirizzamento a una pagina dettagli
    console.log(`Dettagli cliccati per il corso con ID: ${courseId}`);
  };

  return (
    <Router>
      <div className="app-container">
        <Link to="/">
          <img src={logoImage} alt="Logo" className="centered-logo" />
        </Link>
        <h2>Segui Online i tuoi corsi di formazione</h2>
        <p>Assolvi l'obbligo formativo in pochi passaggi</p>
        <div style={{ display: 'inline-block', backgroundColor: '#f0f0f0', margin: 'auto', textAlign: 'center'}}>
        <p>Cerca il tuo corso, aggiungilo al carrello e procedi subito al pagamento, riceverai una mail di conferma</p>
        </div>
        <SearchBar handleSearch={handleSearch} />


        
        {/* Nuova struttura per i corsi disposti orizzontalmente */}
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <div style={{ flex: 1 }}>
            <h2>Elenco Corsi</h2>
            <CourseList
              courses={filteredCourses}
              handleDettagliClick={handleDettagliClick} 
              handleAddToCart={handleAddToCart}
              handleRemoveFromCart={handleRemoveFromCart}
            />
          </div>
        </div>

        <Routes>
          <Route path="/" element={<div />} />
          <Route path="/course-details/:courseId" element={<CourseDetails courses={coursesData} />} />
        </Routes>

        {/* Carrello in alto a destra */}
        <div style={{ position: 'absolute' , top: 100, right: 20 }}>
          <h2>
            <CartIcon style={{ width: '24px', height: '24px', marginRight: '8px' }} />
           ({cart.length})
          </h2>
          <ul>
            {cart.map((item) => (
              <li key={item.id}>
                {item.title}{' '}
                <button onClick={() => handleRemoveFromCart(item.id)}>Rimuovi dal Carrello</button>
              </li>
            ))}
          </ul>
          {cart.length > 0 && <button onClick={procediAlPagamento}>Procedi al Pagamento</button>}
        </div>

        
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: '100px' }}>
          {/* ... (resto del codice per il footer) */}
          <Footer />
        </div>
      </div>
    </Router>
  );
}

export default App;