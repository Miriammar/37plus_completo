// server.js

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();

// Abilita CORS
app.use(cors());

// Connette a MongoDB (assicurati di sostituire 'nome_database' con il nome del tuo database)
mongoose.connect('mongodb://localhost:3000/nome_database', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Schema del modello del corso
const courseSchema = new mongoose.Schema({
  title: String,
  description: String,
});

const Course = mongoose.model('Course', courseSchema);

// Endpoint per ottenere tutti i corsi
app.get('/api/courses', async (req, res) => {
  try {
    const courses = await Course.find();
    res.json(courses);
  } catch (err) {
    res.status(500).send(err);
  }
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server avviato su http://localhost:${PORT}`);
});
