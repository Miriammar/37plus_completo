import React from 'react';

const SearchBar = ({ handleSearch }) => {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
      <input
        type="text"
        placeholder="Cerca corsi..."
        onChange={handleSearch}
        style={{ padding: '8px', width: '300px', marginBottom: '40px'}}
      />
    </div>
  );
};

export default SearchBar;
