import { Link } from 'react-router-dom';


const CourseList = ({ courses, handleAddToCart, handleRemoveFromCart }) => {
  const cardStyle = {
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '10px',
    cursor: 'pointer',
    width: '200px',
  };

  const containerStyle = {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-around', // Allinea le cards in modo uniforme
    gap: '10px',
  };

  return (
    <div style={containerStyle}>
      {courses.map((course) => (
        <div key={course.id} style={cardStyle}>
          <h3>{course.title}</h3>
          <p>{course.description}</p>
          <Link to={`/course-details/${course.id}`}>
            <button>Dettagli</button>
          </Link>
          <button onClick={() => handleAddToCart(course.id)}>Aggiungi al Carrello</button>
          <button onClick={() => handleRemoveFromCart(course.id)}>Rimuovi dal Carrello</button>
        </div>
      ))}
    </div>
  );
};

export default CourseList;

