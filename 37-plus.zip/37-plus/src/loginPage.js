import React from 'react';

const LoginPage = () => {
  return (
    <div className="login-container">
      <h2>Login</h2>
      <table>
        <tbody>
          <tr>
            <td>Username:</td>
            <td><input type="text" placeholder="Inserisci il tuo username" /></td>
          </tr>
          <tr>
            <td>Password:</td>
            <td><input type="password" placeholder="Inserisci la tua password" /></td>
          </tr>
        </tbody>
      </table>
      <button>Login</button>
    </div>
  );
};

export default LoginPage;

